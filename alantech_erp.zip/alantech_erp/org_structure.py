"""
Alantech organisation structure and role management (source: AIS-MS-TP-01, version 01, 02-09-2024).

Place at:  apps/alantech_erp/alantech_erp/org_structure.py

Run (safe to re-run; it updates instead of duplicating):
    bench --site alantech.localhost execute alantech_erp.org_structure.execute

What it creates
    * Custom roles for Alantech-specific work (BOQ / proposals, design)
    * Role Profiles (one bundle of standard ERPNext/HRMS roles per job family)
    * Departments for the company
    * Designations, each with: reports-to designation, default department, role profile
      (stored in custom fields alt_reports_to, alt_default_department, alt_role_profile)

Employee hooks (wire them in hooks.py, see bottom of file)
    * On save, an employee with a designation gets the default department and,
      the Reports To: the active employee holding the parent designation (the first created one
      when there are several). When nobody holds it (vacant post), the Managing Director.
    * If the employee has a linked User with no role profile yet, the designation's
      role profile is applied to that user.
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

# ---------------------------------------------------------------------------
# Roles
# ---------------------------------------------------------------------------
CUSTOM_ROLES = [
    "Proposal Engineer",  # technical-commercial quotes, BOQ (custom doctypes come later)
    "Design Engineer",  # BOM / drawings ownership, design approvals in workflows
    "Quotation Level 2 Approver",  # quotations above the Selling Settings limit (alantech_erp.sales)
]

EMP = ["Employee"]
APPROVER = ["Leave Approver", "Expense Approver"]

ROLE_PROFILES = {
    # Management
    "ALT Managing Director": [
        "Accounts Manager", "Sales Manager", "Purchase Manager", "Stock Manager",
        "Manufacturing Manager", "Projects Manager", "HR Manager", "Quality Manager",
        "Auditor", "Report Manager", "Analytics", "Quotation Level 2 Approver", *APPROVER, *EMP,
    ],
    # Finance & purchase
    "ALT Finance Manager": [
        "Accounts Manager", "Accounts User", "Purchase Manager", "Auditor",
        "Report Manager", "Analytics", *APPROVER, *EMP,
    ],
    "ALT Accounts Head": [
        "Accounts Manager", "Accounts User", "Report Manager", "Leave Approver",
        "Loan Manager",  # Lending app (workspace is restricted to Loan Manager)
        *EMP,
    ],
    "ALT Accounts Executive": ["Accounts User", *EMP],
    "ALT Internal Auditor": ["Auditor", "Report Manager", "Leave Approver", *EMP],
    "ALT Audit Executive": ["Auditor", *EMP],
    "ALT Purchase Manager": [
        "Purchase Manager", "Purchase Master Manager", "Purchase User", "Stock User",
        "Leave Approver", *EMP,
    ],
    "ALT Purchase Executive": ["Purchase User", "Stock User", *EMP],
    # Sales & marketing
    # Sales line (Sales Director -> Sales Managers -> Sales Engineers, see sales/hierarchy.py)
    "ALT Sales Director": [
        "Sales Manager", "Sales Master Manager", "Sales User", "Projects User",
        "Report Manager", "Quotation Level 2 Approver", *APPROVER, *EMP,
    ],
    "ALT Sales Manager": ["Sales Manager", "Sales User", "Leave Approver", *EMP],
    "ALT Sales Engineer": ["Sales User", *EMP],
    "ALT Proposal Engineer": ["Sales User", "Proposal Engineer", *EMP],
    "ALT Sales Coordinator": ["Sales User", "Report Manager", *EMP],
    "ALT Marketing Manager": ["Sales Manager", "Sales User", "Leave Approver", *EMP],
    "ALT Marketing Executive": ["Sales User", *EMP],
    # HR
    "ALT HR Manager": ["HR Manager", "HR User", *APPROVER, *EMP],
    "ALT HR Executive": ["HR User", *EMP],
    # Operations
    "ALT Operations Manager": [
        "Manufacturing Manager", "Projects Manager", "Stock Manager", "Quality Manager",
        "Maintenance Manager", "Item Manager", "Purchase User", "Report Manager",
        *APPROVER, *EMP,
    ],
    "ALT Design Head": [
        "Manufacturing User", "Item Manager", "Projects User", "Design Engineer",
        "Leave Approver", *EMP,
    ],
    "ALT Design Engineer": ["Manufacturing User", "Projects User", "Design Engineer", *EMP],
    "ALT Engineering Lead": ["Manufacturing User", "Projects User", "Leave Approver", *EMP],
    "ALT Engineer": ["Manufacturing User", "Projects User", *EMP],
    "ALT Quality Controller": ["Quality Manager", "Stock User", "Manufacturing User", "Leave Approver", *EMP],
    "ALT Jr Quality Controller": ["Stock User", "Manufacturing User", *EMP],
    "ALT Aftersales Coordinator": [
        "Maintenance Manager", "Maintenance User", "Support Team", "Sales User",
        "Projects User", "Leave Approver", *EMP,
    ],
    "ALT Service Engineer": ["Maintenance User", "Support Team", *EMP],
    # Production
    "ALT Production Manager": [
        "Manufacturing Manager", "Manufacturing User", "Stock User", "Projects User",
        *APPROVER, *EMP,
    ],
    "ALT Production Supervisor": ["Manufacturing User", "Stock User", "Leave Approver", *EMP],
    "ALT Store Keeper": ["Stock Manager", "Stock User", "Leave Approver", *EMP],
    "ALT Store Assistant": ["Stock User", *EMP],
    "ALT Logistics Executive": ["Stock User", "Delivery User", *EMP],
    # Shop floor (usually no ERP login; employee self-service only)
    "ALT Shop Floor": [*EMP],
}

# ---------------------------------------------------------------------------
# Departments (flat under "All Departments"; hierarchy lives in reports-to)
# ---------------------------------------------------------------------------
DEPARTMENTS = [
    "Management", "Accounts", "Internal Audit", "Purchase", "Sales", "Marketing",
    "Human Resources", "Operations", "Design", "Process Design", "Automation",
    "Quality Control", "Aftersales", "Production", "Electrical", "Stores", "Logistics",
]

# ---------------------------------------------------------------------------
# Designations: (designation, reports to, default department, role profile)
# ---------------------------------------------------------------------------
DESIGNATIONS = [
    # Management team
    ("Managing Director", None, "Management", "ALT Managing Director"),
    ("Finance Manager", "Managing Director", "Accounts", "ALT Finance Manager"),
    ("Sales Director", "Managing Director", "Sales", "ALT Sales Director"),
    ("HR Manager", "Managing Director", "Human Resources", "ALT HR Manager"),
    ("Operations Manager", "Managing Director", "Operations", "ALT Operations Manager"),
    ("Marketing Manager", "Managing Director", "Marketing", "ALT Marketing Manager"),
    ("HR Executive", "HR Manager", "Human Resources", "ALT HR Executive"),
    ("Marketing Executive", "Marketing Manager", "Marketing", "ALT Marketing Executive"),
    # Finance & purchase team
    ("Internal Auditor", "Finance Manager", "Internal Audit", "ALT Internal Auditor"),
    ("Audit Executive", "Internal Auditor", "Internal Audit", "ALT Audit Executive"),
    ("Accounts Head", "Finance Manager", "Accounts", "ALT Accounts Head"),
    ("Accounts Executive", "Accounts Head", "Accounts", "ALT Accounts Executive"),
    ("Purchase Manager", "Finance Manager", "Purchase", "ALT Purchase Manager"),
    ("Purchase Executive", "Purchase Manager", "Purchase", "ALT Purchase Executive"),
    # Sales team (regions Kerala / Bangalore / Hyderabad / UAE are Territories, not designations)
    # Sales line: Sales Director -> Sales Managers -> Sales Engineers (the Sales Person tree)
    ("Sales Manager", "Sales Director", "Sales", "ALT Sales Manager"),
    ("Sales Engineer", "Sales Manager", "Sales", "ALT Sales Engineer"),
    # Report to Management, outside the sales line (CRM workflow deck, org chart)
    ("Proposal Engineer", "Managing Director", "Sales", "ALT Proposal Engineer"),
    ("Sales Co-ordinator", "Managing Director", "Sales", "ALT Sales Coordinator"),
    # Operations team
    ("Production Manager", "Operations Manager", "Production", "ALT Production Manager"),
    ("Design Head", "Operations Manager", "Design", "ALT Design Head"),
    ("Design Engineer", "Design Head", "Design", "ALT Design Engineer"),
    ("Process Design Engineer", "Operations Manager", "Process Design", "ALT Engineering Lead"),
    ("Jr. Process Design Engineer", "Process Design Engineer", "Process Design", "ALT Engineer"),
    ("Sr. Automation Engineer", "Operations Manager", "Automation", "ALT Engineering Lead"),
    ("Automation Engineer", "Sr. Automation Engineer", "Automation", "ALT Engineer"),
    ("Quality Controller", "Operations Manager", "Quality Control", "ALT Quality Controller"),
    ("Jr. Quality Controller", "Quality Controller", "Quality Control", "ALT Jr Quality Controller"),
    # Aftersales team
    ("Aftersales Coordinator", "Operations Manager", "Aftersales", "ALT Aftersales Coordinator"),
    ("Process Engineer", "Aftersales Coordinator", "Aftersales", "ALT Engineer"),
    ("Jr. Process Engineer", "Process Engineer", "Aftersales", "ALT Engineer"),
    ("Service Engineer", "Aftersales Coordinator", "Aftersales", "ALT Service Engineer"),
    ("Jr. Service Engineer", "Service Engineer", "Aftersales", "ALT Service Engineer"),
    # Production team
    ("Production Supervisor", "Production Manager", "Production", "ALT Production Supervisor"),
    ("Fabricator", "Production Supervisor", "Production", "ALT Shop Floor"),
    ("Machinist", "Production Supervisor", "Production", "ALT Shop Floor"),
    ("Turner", "Production Supervisor", "Production", "ALT Shop Floor"),
    ("Welder", "Production Supervisor", "Production", "ALT Shop Floor"),
    ("Fitter", "Production Supervisor", "Production", "ALT Shop Floor"),
    ("Helper", "Production Supervisor", "Production", "ALT Shop Floor"),
    ("Electrical Head", "Production Manager", "Electrical", "ALT Engineering Lead"),
    ("Electrician", "Electrical Head", "Electrical", "ALT Shop Floor"),
    ("Electrical Engineer", "Production Manager", "Electrical", "ALT Engineer"),
    ("Store Keeper", "Production Manager", "Stores", "ALT Store Keeper"),
    ("Store Assistant", "Store Keeper", "Stores", "ALT Store Assistant"),
    ("Logistics Executive", "Production Manager", "Logistics", "ALT Logistics Executive"),
]

CUSTOM_FIELDS = {
    "Designation": [
        {
            "fieldname": "alt_reports_to",
            "label": "Reports To (Designation)",
            "fieldtype": "Link",
            "options": "Designation",
            "insert_after": "designation_name",
        },
        {
            "fieldname": "alt_default_department",
            "label": "Default Department",
            "fieldtype": "Link",
            "options": "Department",
            "insert_after": "alt_reports_to",
        },
        {
            "fieldname": "alt_role_profile",
            "label": "Role Profile",
            "fieldtype": "Link",
            "options": "Role Profile",
            "insert_after": "alt_default_department",
        },
    ]
}


# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------
def execute(company=None):
    company = company or frappe.defaults.get_global_default("company") or frappe.db.get_value("Company", {}, "name")
    if not company:
        frappe.throw("No Company found. Finish the setup wizard first.")
    print(f"Company: {company}")

    create_custom_fields(CUSTOM_FIELDS, update=True)
    _create_roles()
    missing = _create_role_profiles()
    dept_names = _create_departments(company)
    _create_designations(dept_names)
    frappe.db.commit()

    print(f"Roles: {len(CUSTOM_ROLES)} custom | Role profiles: {len(ROLE_PROFILES)} | "
          f"Departments: {len(DEPARTMENTS)} | Designations: {len(DESIGNATIONS)}")
    if missing:
        print("Skipped roles not present on this site:", ", ".join(sorted(missing)))


def _create_roles():
    for role in CUSTOM_ROLES:
        if not frappe.db.exists("Role", role):
            frappe.get_doc({"doctype": "Role", "role_name": role, "desk_access": 1}).insert(ignore_permissions=True)


def _create_role_profiles():
    missing = set()
    for profile, roles in ROLE_PROFILES.items():
        valid = []
        for r in dict.fromkeys(roles):  # de-duplicate, keep order
            if frappe.db.exists("Role", r):
                valid.append(r)
            else:
                missing.add(r)
        if frappe.db.exists("Role Profile", profile):
            doc = frappe.get_doc("Role Profile", profile)
            doc.set("roles", [])
        else:
            doc = frappe.new_doc("Role Profile")
            doc.role_profile = profile
        for r in valid:
            doc.append("roles", {"role": r})
        doc.save(ignore_permissions=True)
    return missing


def _create_departments(company):
    root = frappe.db.get_value("Department", {"is_group": 1, "parent_department": ["in", ["", None]]}, "name") \
        or "All Departments"
    names = {}
    for dept in DEPARTMENTS:
        name = frappe.db.get_value("Department", {"department_name": dept, "company": company}, "name")
        if not name:
            doc = frappe.get_doc({
                "doctype": "Department",
                "department_name": dept,
                "company": company,
                "parent_department": root,
            }).insert(ignore_permissions=True)
            name = doc.name
        names[dept] = name
    return names


def _create_designations(dept_names):
    for desig, *_ in DESIGNATIONS:
        if not frappe.db.exists("Designation", desig):
            frappe.get_doc({"doctype": "Designation", "designation_name": desig}).insert(ignore_permissions=True)

    for desig, reports_to, dept, profile in DESIGNATIONS:
        frappe.db.set_value("Designation", desig, {
            "alt_reports_to": reports_to,
            "alt_default_department": dept_names.get(dept),
            "alt_role_profile": profile,
        }, update_modified=False)


# ---------------------------------------------------------------------------
# Employee hooks
# ---------------------------------------------------------------------------
def apply_designation_defaults(doc, method=None):
    """Employee.validate: Department and Reports To from the designation (Designation's Default
    Department and Reports To post, the organisation chart AIS-MS-TP-01).

    - Empty: filled from the designation.
    - Designation changed (ClickUp 14yr2e58fq1): they follow the new designation, unless they
      were changed by hand in the same save. A promotion to Managing Director clears Reports To.
      A designation without a Reports To post leaves Reports To as it was.
    """
    if not doc.designation:
        return
    dept, reports_to = designation_department(doc.designation, doc.company), designation_reports_to(doc)

    # a plain dict (tests, the form's call) is a new employee
    from frappe.model.document import Document

    before = doc.get_doc_before_save() if isinstance(doc, Document) and not doc.is_new() else None
    designation_changed = bool(before) and before.designation != doc.designation

    def untouched(field):
        return designation_changed and before.get(field) == doc.get(field)

    if dept and (not doc.department or untouched("department")):
        doc.department = dept

    if not doc.reports_to:
        if reports_to:
            doc.reports_to = reports_to
    elif untouched("reports_to"):
        if doc.designation == TOP_DESIGNATION:
            doc.reports_to = None
        elif reports_to:
            doc.reports_to = reports_to


def designation_department(designation, company):
    """The designation's Default Department, if it belongs to `company`."""
    dept = frappe.db.get_value("Designation", designation, "alt_default_department")
    if dept and frappe.db.get_value("Department", dept, "company") == company:
        return dept
    return None


def designation_reports_to(doc):
    """The manager an employee with `doc.designation` reports to: a holder of the designation's
    Reports To post who is a manager; the Managing Director when that post is vacant; None when the
    designation has no Reports To post (or is the top post)."""
    parent_desig = frappe.db.get_value("Designation", doc.designation, "alt_reports_to")
    if not parent_desig:
        return None
    from alantech_erp.setup.reports_to import manager_holders

    # only a holder who is a manager (setup/reports_to.py, ClickUp 14yr2e57t0m)
    managers = manager_holders(_active_holders(parent_desig, doc))
    if not managers:  # parent post vacant (or no manager in it): the Managing Director
        managers = manager_holders(_active_holders(TOP_DESIGNATION, doc))
    # several (e.g. two Production Managers): the first created one
    return managers[0] if managers else None


TOP_DESIGNATION = "Managing Director"


@frappe.whitelist()
def designation_defaults(designation: str, company: str | None = None, employee: str | None = None) -> dict:
    """Employee form: the Department and Reports To of `designation` (the ones
    apply_designation_defaults fills on save), shown as soon as the designation is picked or
    changed. `employee` is left out of the Reports To candidates (no one reports to themselves)."""
    frappe.has_permission("Employee", "read", throw=True)
    doc = frappe._dict(designation=designation, company=company, name=employee or "")
    return {
        "department": designation_department(designation, company),
        "reports_to": None if designation == TOP_DESIGNATION else designation_reports_to(doc),
        "is_top": designation == TOP_DESIGNATION,
    }


def fill_vacant_post(doc, method=None):
    """Employee.on_update: someone now holds a post that was vacant. The employees under that post
    who were given the Managing Director as a stand-in move to them, if they are its only holder."""
    if not doc.designation or doc.status != "Active" or doc.designation == TOP_DESIGNATION:
        return
    before = doc.get_doc_before_save()
    if before and before.designation == doc.designation and before.status == doc.status:
        return
    if len(_active_holders(doc.designation, frappe._dict(company=doc.company, name=""))) != 1:
        return
    from alantech_erp.setup.reports_to import is_manager

    from alantech_erp.setup.reports_to import rule_active

    if rule_active() and not is_manager(doc.name):  # no manager role yet (e.g. no user): the MD stays meanwhile
        return
    child_desigs = frappe.get_all("Designation", filters={"alt_reports_to": doc.designation}, pluck="name")
    md = _active_holders(TOP_DESIGNATION, doc)
    if not child_desigs or len(md) != 1:
        return
    for name in frappe.get_all(
        "Employee",
        filters={"designation": ["in", child_desigs], "company": doc.company,
                 "status": "Active", "reports_to": md[0], "name": ["!=", doc.name]},
        pluck="name",
    ):
        emp = frappe.get_doc("Employee", name)
        emp.reports_to = doc.name
        emp.flags.ignore_permissions = True
        emp.save()  # validate also moves the approvers that followed the MD (setup/approvers.py)


def fill_missing_reports_to():
    """after_migrate: give existing employees without a Reports To the one their designation implies.
    Values already set are never changed."""
    for name in frappe.get_all(
        "Employee", filters={"status": "Active", "reports_to": ["is", "not set"],
                             "designation": ["is", "set"]}, pluck="name"
    ):
        emp = frappe.get_doc("Employee", name)
        apply_designation_defaults(emp)
        if emp.reports_to:
            emp.flags.ignore_permissions = True
            emp.save()
    frappe.db.commit()


def _active_holders(designation, doc):
    return frappe.get_all(
        "Employee",
        filters={"designation": designation, "company": doc.company,
                 "status": "Active", "name": ["!=", doc.name or ""]},
        pluck="name",
        order_by="creation asc",
        limit=2,
    )


def sync_user_role_profile(doc, method=None):
    """Employee.on_update: give the linked user the designation's role profile, never overriding one set by hand."""
    if not (doc.user_id and doc.designation) or doc.user_id in ("Administrator", "Guest"):
        return
    profile = frappe.db.get_value("Designation", doc.designation, "alt_role_profile")
    if not profile:
        return

    user = frappe.get_doc("User", doc.user_id)
    if user.meta.has_field("role_profiles"):  # newer Frappe: multiple role profiles per user
        if user.get("role_profiles"):
            return
        user.append("role_profiles", {"role_profile": profile})
    else:
        if user.get("role_profile_name"):
            return
        user.role_profile_name = profile
    user.save(ignore_permissions=True)

def setup_if_ready():
    """after_migrate hook: run the org setup once a Company exists (skips silently on a fresh site)."""
    if not frappe.db.get_value("Company", {}, "name"):
        return
    execute()


# ---------------------------------------------------------------------------
# hooks.py additions
# ---------------------------------------------------------------------------
# doc_events = {
#     "Employee": {
#         "validate": "alantech_erp.org_structure.apply_designation_defaults",
#         "on_update": "alantech_erp.org_structure.sync_user_role_profile",
#     }
# }
#
# fixtures += [
#     {"dt": "Role", "filters": [["name", "in", ["Proposal Engineer", "Design Engineer"]]]},
#     {"dt": "Role Profile", "filters": [["name", "like", "ALT %"]]},
#     {"dt": "Designation"},
#     {"dt": "Department"},
# ]
