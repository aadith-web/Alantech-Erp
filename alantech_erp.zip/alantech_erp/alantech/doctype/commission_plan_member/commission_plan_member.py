# Copyright (c) 2026, JincyTricta and contributors
# For license information, please see license.txt
from frappe.model.document import Document


class CommissionPlanMember(Document):
	pass
